package com.krypturg.Entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import java.time.LocalDate;

@Entity
@Table(name = "orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String email;
    private String address;
    private int total;
    private String items;
    private String status;
    private LocalDate order_Date;

    public LocalDate getOrder_Date() {
		return order_Date;
	}

	public void setOrder_Date(LocalDate order_Date) {
		this.order_Date = order_Date;
	}

	@PrePersist
    public void prePersist() {
		order_Date = LocalDate.now();
    }

    public Order() {
    }

    public Order(String email, String address, int total, String items, String status) {
        this.email = email;
        this.address = address;
        this.total = total;
        this.items = items;
        this.status = status;
        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public String getItems() {
        return items;
    }

    public void setItems(String items) {
        this.items = items;
    }

    

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

	
}

