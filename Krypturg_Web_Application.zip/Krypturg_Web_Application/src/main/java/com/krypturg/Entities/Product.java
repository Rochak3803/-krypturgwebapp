package com.krypturg.Entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "product")
public class Product {
    @Id
    private String name;
    private int price;
    private String cname;
    private String category;
    private String description;
    private int qty;
    
    @Lob
    private byte[] image;

    // Constructors, Getters, and Setters

    public Product() {
        // Default constructor
    }

    public Product(String name, int price, String cname, String category, String description, int qty, byte[] image) {
        this.name = name;
        this.price = price;
        this.cname = cname;
        this.category = category;
        this.description = description;
        this.qty = qty;
        this.image = image;
    }

    // Getters and Setters for other fields

    // Getter and Setter for name
    public String getName() {
        return name;
    }

    public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}

	public void setName(String name) {
        this.name = name;
    }
}
