package com.krypturg.controllers;

import org.hibernate.SessionFactory;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.krypturg.conn.HibernateUtil;
import com.krypturg.model.DAO;

@WebServlet("/AddPcToCart")
public class AddPcToCart extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private DAO dao;

    @Override
    public void init() throws ServletException {
        super.init();
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        dao = new DAO(sessionFactory);
    }

    @Override
    public void destroy() {
        super.destroy();
        dao.closeSession();
    }

    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            HttpSession session = request.getSession();
            String email = (String) session.getAttribute("email");

            String motherboard = request.getParameter("motherboard");
            String harddisk = request.getParameter("harddisk");
            String ram = request.getParameter("ram");
            String processor = request.getParameter("processor");
            String mouse = request.getParameter("mouse");
            String keyboard = request.getParameter("keyboard");
            String webcam = request.getParameter("webcam");
            String ups = request.getParameter("ups");
            String cabinate = request.getParameter("cabinate");

            dao.addToCart(email, motherboard);
            dao.addToCart(email, harddisk);
            dao.addToCart(email, ram);
            dao.addToCart(email, processor);
            dao.addToCart(email, mouse);
            dao.addToCart(email, keyboard);
            dao.addToCart(email, webcam);
            dao.addToCart(email, ups);
            dao.addToCart(email, cabinate);

            session.setAttribute("msg", "PC Build Successfully!");
            response.sendRedirect("Cart.jsp");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("ExpPage.jsp");
        }
    }
}
