package com.krypturg.controllers;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.SessionFactory;

import com.krypturg.conn.HibernateUtil;
import com.krypturg.model.DAO;

@WebServlet("/AdminLogin")
public class AdminLogin extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private DAO dao;

    @Override
    public void init() throws ServletException {
        super.init();
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        dao = new DAO(sessionFactory); // Initialize the dao object with the sessionFactory
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String id = request.getParameter("id");
            String password = request.getParameter("password");
            
            String name = dao.adminLogin(id, password);
            
            HttpSession session = request.getSession();
            if (name != null) {
                session.setAttribute("adminName", name);
                response.sendRedirect("AdminHome.jsp");
            } else {
                session.setAttribute("msg", "Invalid Entries!");
                response.sendRedirect("index.jsp");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            response.sendRedirect("ExpPage.jsp");
        }
    }
}
