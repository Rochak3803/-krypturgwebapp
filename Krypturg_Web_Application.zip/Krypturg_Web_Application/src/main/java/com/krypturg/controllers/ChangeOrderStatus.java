package com.krypturg.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.krypturg.conn.HibernateUtil;
import com.krypturg.model.DAO;
import com.krypturg.model.SendMail;

@WebServlet("/ChangeOrderStatus")
public class ChangeOrderStatus extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String page = request.getParameter("page");
            String status = request.getParameter("status");
            String email = request.getParameter("email");
            int id = Integer.parseInt(request.getParameter("id"));

            DAO dao = new DAO(HibernateUtil.getSessionFactory());
            dao.changeOrderStatus(id, status);

            //mail send
            String sub = "Order Status Update";
            String body = "Your Order Status is " + status;
            SendMail.sendMail(email, sub, body);
            //mail code ends

            HttpSession session = request.getSession();
            session.setAttribute("msg", "Status Updated Successfully!");
            response.sendRedirect(page + ".jsp");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("ExpPage.jsp");
        }
    }
}
