package com.krypturg.controllers;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.krypturg.Entities.Order;
import com.krypturg.model.DAO;
import com.krypturg.model.SendMail;
import com.krypturg.conn.HibernateUtil;

@WebServlet("/OrderPlaced")
public class OrderPlaced extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            HttpSession session = request.getSession();
            String email = (String) session.getAttribute("email");
            if (email == null) {
                session.setAttribute("msg", "Please Login First!");
                response.sendRedirect("User.jsp");
            } else {
                String address = request.getParameter("address");

                SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
                DAO dao = new DAO(sessionFactory);

                dao.orderPlaced(email, address);

                // Mail sending code
                String subject = "Order Placed";
                String body = "Your order has been placed successfully.";
                SendMail sendMail = new SendMail(sessionFactory);
                sendMail.sendMail(email, subject, body);

                session.setAttribute("msg", "Order Placed Successfully!");
                response.sendRedirect("UserHome.jsp");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("ExpPage.jsp");
        }
    }
}
